=================
Verify OSPF state
=================

.. raw:: html

   <!-- This class allows us to hide the test setup part -->
   <style type="text/css">.hidden { display: none; }</style>

.. contents::
    :local:

This example demonstrates how RobotFramework tests can be embedded in
ReStructuredText documentation.  If you are converting an existing
tab-separated test suite, convert tabs to 4-spaces within the RST file.

The testcases should be in `code:: robotframework` blocks.

Installing RobotFramework
=========================

To execute this test, setup the following::

    pip install robotframework docutils Pygments
    git clone https://github.com/arista-eosplus/robotframework-aristalibrary.git
    cd robotframework-aristalibrary/
    python setup.py install


Executing tests
===============

Start tests using one of the examples, below::

    robot demo/sample_test_refactored.rst

    robot --variable SW1_HOST:localhost --variable SW1_PORT:61080 \
          --variable USERNAME:eapiuser --variable PASSWORD:icanttellyou \
          demo/sample_test_refactored.rst

    robot --variablefile demo/myvariables.py
          demo/sample_test_refactored.rst

Variable files
--------------

Variable files are just python modules with KEY = value pairs.

Example `myvariables.py`::

    """ My custom values for this test suite
    """

    SW1_HOST = 'localhost'
    SW1_PORT = 61080
    USERNAME = 'eapiuser'
    PASSWORD = 'icanttellyou'

Suite Setup
===========

.. code:: robotframework
   :class: hidden

    *** Settings ***
    Library    AristaLibrary
    Library    AristaLibrary.Expect
    Library    Collections
    Library    String
    Suite Setup    Connect To Switches
    Suite Teardown    Clear All Connections
    Force Tags    OSPF

    *** Variables ***
    ${TRANSPORT}    http
    ${SW1_HOST}    localhost
    ${SW1_PORT}    2080
    ${USERNAME}    vagrant
    ${PASSWORD}    vagrant

    *** Keywords ***
    Connect To Switches
        [Documentation]    Establish connection to a switch which gets used by test cases.
        Connect To    host=${SW1_HOST}    transport=${TRANSPORT}    username=${USERNAME}    password=${PASSWORD}    port=${SW1_PORT}
        ${result}=  Get Command Output  cmd=show running-config section router ospf
        # Skip this suite if mlag is disabled
        Run Keyword If   'router ospf' not in "${result}"  Fail   OSPF is not configured on this device  not_enabled

Test Cases
===============

.. code:: robotframework

    *** Test Cases ***
    OSPF Neighbor adjancey should be Full
        [TAGS]  production
        ${ospf}=  Get Command Output  cmd=show ip ospf neighbor
        Record Output
        Log  ${ospf}
        ${result}=    Get Dictionary Items    ${ospf}
        ${vrfs}=    Get From Dictionary    ${result[1]}    vrfs
        ${v_default}=    Get From Dictionary    ${vrfs}    default
        ${instList}=    Get From Dictionary    ${v_default}    instList
        ${instance_1}=    Get From Dictionary    ${instList}    1
        ${neighbors}=    Get From Dictionary    ${instance_1}    ospfNeighborEntries
        #Expect  config  to contain  ip name-server vrf default 10.81.98.70
        #${result}=  Get Running Config
        #Log    ${result}
        #Run Keyword If   'ip name-server' not in "'${result}'"   Fail   name-servers not enabled on this device  not_enabled
        #Name Server ${server} Is Reachable via VRF ${vrf}
        #${matches}=     get regexp matches      ${result}   ntp server ([^\\s]*)     1
        #Log    ${matches}
        :FOR  ${neighbor}  IN  @{neighbors}
        \    Log  ${neighbor}
        \    ${state}=    Get From Dictionary    ${neighbor}    adjacencyState
        \    Should Be Equal  ${state}  full  Adjacency state is not full

    #Clock is synchronized to NTP
    #    [TAGS]  production
    #    #Get Command Output	cmd=show ntp status
    #    #Expect 'full output' 
    #    ${output}=  Enable  show ntp status  text
    #    ${resp}=    Get From Dictionary    ${output[0]}    result
    #    ${result}=    Get From Dictionary    ${resp}    output
    #    Should Start With  ${result}  synchronised to NTP server

End of testplan.
