The Arista Network Validation Suite
===================================

Introduction
------------

Arista Network Validation is a collection of automated tests for network
devices and a configurable test runner toenable network engineers to rapidly
and consistently verify that their network is working as expected.  This is not
a substiture for network monitoring and alerting systems such as CloudVision
Telemetry.  Network Validation provides tooling to customize and perform code
certifications (acceptance testing) of new devices and software releases, and
is useful as a key part of a configuration management workflow to ensure that
changes are successful and do not negatively impact other services on the
network.

Prerequisites
-------------

* `Robot Framework <http://robotframework.org/>`
* `PyEAPI <https://pypi.python.org/pypi/pyeapi>` (`GitHub <https://github.com/arista-eosplus/pyeapi>`)
* `AristaLibrary for RobotFramework <https://pypi.python.org/pypi/robotframework-aristalibrary>` (`GitHub <https://github.com/aristanetworks/robotframework-aristalibrary>`)
* `Arista EOS <http://www.arista.com>` 4.12 or later
* Python 2.7

Installation
------------

Download the package from `Arista Software Downloads
<https://www.arista.com/en/support/software-download>`.

The easiest way to install is to use `pip <http://www.pip-installer.org/en/latest/>`::

    pip install /<path to>/network_validation-0.1.tar.gz

Upgrade using::

    pip install --upgrade /<path to>/network_validation-0.1.tar.gz

Keyword Documentation
---------------------

See the `AristaLibrary <http://aristanetworks.github.io/robotframework-aristalibrary/AristaLibrary.html>` keyword documentation.

Release Notes
-------------

Release notes are available in the GitHub `releases
<https://github.com/aristanetworks/arista-eosplus/network_validation/releases>`.

Support and Contacts
--------------------

This project is maintained by Arista EOS+ Consulting Services.  Contact the
maintainers at `eosplus-dev@arista.com`.

Contributing
------------

Contributing is encouraged via pull requests. Please see `<CONTRIBUTING.rst>`_
for more information.

License
-------

All code within this repository is proprietary and licensed according to the
terms of your Arista software licensing agreement.
