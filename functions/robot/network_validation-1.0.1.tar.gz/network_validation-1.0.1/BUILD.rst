Contributing to Networwk Validation
===================================


Releasing a new version
-----------------------

1. Create a release branch

   ``git checkout -b release-X.Y develop``

2. Update the VERSION identifier

   Edit ``VERSION`` then commit changes

3. Finish the release branch

   * ``git checkout master``
   * ``git merge --no-ff release-X.Y``
   * ``git tag -a vX.Y -m "Release X.Y" && git push --tags``
   * ``git checkout develop``
   * ``git merge --no-ff release-X.Y``  # Then resolve conflicts and commit.
   * ``git branch -d release-X.Y``

4. Generate a GitHub Release and include release notes

   `https://github.com/arista-eosplus/network_validation/releases`

5. Publish to Arista Software Downloads

6. Publish news

   * EOS Central
   * Email
   * Publish news to other sites?

Contact
-------

Contact eosplus-dev@arista.com with any questions or comments on this library.
