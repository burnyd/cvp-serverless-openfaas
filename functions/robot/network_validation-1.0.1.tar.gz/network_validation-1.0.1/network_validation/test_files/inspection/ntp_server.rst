================================
Verify NTP servers are reachable
================================

.. raw:: html

   <!-- This class allows us to hide the test setup part -->
   <style type="text/css">.hidden { display: none; }</style>

.. contents::
    :local:

This example demonstrates how RobotFramework tests can be embedded in
ReStructuredText documentation.  If you are converting an existing
tab-separated test suite, convert tabs to 4-spaces within the RST file.

The testcases should be in `code:: robotframework` blocks.

Installing RobotFramework
=========================

To execute this test, setup the following::

    pip install robotframework docutils Pygments
    git clone https://github.com/arista-eosplus/robotframework-aristalibrary.git
    cd robotframework-aristalibrary/
    python setup.py install


Executing tests
===============

Start tests using one of the examples, below::

    robot demo/sample_test_refactored.rst

    robot --variable SW1_HOST:localhost --variable SW1_PORT:61080 \
          --variable USERNAME:eapiuser --variable PASSWORD:icanttellyou \
          demo/sample_test_refactored.rst

    robot --variablefile demo/myvariables.py
          demo/sample_test_refactored.rst

Variable files
--------------

Variable files are just python modules with KEY = value pairs.

Example `myvariables.py`::

    """ My custom values for this test suite
    """

    SW1_HOST = 'localhost'
    SW1_PORT = 61080
    USERNAME = 'eapiuser'
    PASSWORD = 'icanttellyou'
    MLAG_DOMAIN = 'my_lag_domain'

Suite Setup
===========

.. code:: robotframework
   :class: hidden

    *** Settings ***
    Library    AristaLibrary
    Library    AristaLibrary.Expect
    Library    Collections
    Library    String
    Suite Setup    Connect To Switches
    Suite Teardown    Clear All Connections
    Force Tags    NTP

    *** Variables ***
    ${TRANSPORT}    http
    ${SW1_HOST}    localhost
    ${SW1_PORT}    2080
    ${USERNAME}    vagrant
    ${PASSWORD}    vagrant

    *** Keywords ***
    Connect To Switches
        [Documentation]    Establish connection to a switch which gets used by test cases.
        Connect To    host=${SW1_HOST}    transport=${TRANSPORT}    username=${USERNAME}    password=${PASSWORD}    port=${SW1_PORT}
        #${output}=    Enable    show mlag   json
        #${result}=    Get From Dictionary    ${output[0]}    result
        # Skip this suite if mlag is disabled
        #Run Keyword If   "${result['state']}" == 'disabled'  Fail   MLAG not enabled on this device  not_enabled
        #Set Suite Variable  ${MLAG}  ${result}

    Server ${server} Is Reachable via VRF ${vrf}
        # Ping the peer address
        ${output}=    Enable    ping vrf ${vrf} ${server}    text
        ${result}=    Get From Dictionary    ${output[0]}    result
        Log    ${result}
        ${match}    ${group1}=    Should Match Regexp    ${result['output']}    (\\d+)% packet loss
        Should Be Equal As Integers    ${group1}    0    msg="Packets lost percent not zero!!!"

Test Cases
===============

.. code:: robotframework

    *** Test Cases ***
    NTP Servers Are Reachable
        [TAGS]  production
        Get Command Output	cmd=show running-config section ntp server
        #Record Output
        #Expect  config  to contain  ip name-server vrf default 10.81.98.70
        ${result}=  Get Running Config
        Log    ${result}
        #Run Keyword If   'ip name-server' not in "'${result}'"   Fail   name-servers not enabled on this device  not_enabled
        #Name Server ${server} Is Reachable via VRF ${vrf}
        ${matches}=     get regexp matches      ${result}   ntp server ([^\\s]*)     1
        Log    ${matches}
        :FOR  ${entry}  IN  @{matches}
        \    Log  ${entry}
        \    Server ${entry} Is Reachable via VRF default

    Clock is synchronized to NTP
        [TAGS]  production
        #Get Command Output	cmd=show ntp status
        #Expect 'full output' 
        ${output}=  Enable  show ntp status  text
        ${resp}=    Get From Dictionary    ${output[0]}    result
        ${result}=    Get From Dictionary    ${resp}    output
        Should Start With  ${result}  synchronised to NTP server

End of testplan.
