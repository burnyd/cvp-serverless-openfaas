========================================
Sample Test Example in RST documentation
========================================

.. raw:: html

   <!-- This class allows us to hide the test setup part -->
   <style type="text/css">.hidden { display: none; }</style>

.. contents::
    :local:

This example demonstrates how RobotFramework tests can be embedded in
ReStructuredText documentation.  If you are converting an existing
tab-separated test suite, convert tabs to 4-spaces within the RST file.

The testcases should be in `code:: robotframework` blocks.

Installing RobotFramework
=========================

To execute this test, setup the following::

    pip install robotframework docutils Pygments
    git clone https://github.com/arista-eosplus/robotframework-aristalibrary.git
    cd robotframework-aristalibrary/
    python setup.py install


Executing tests
===============

Start tests using one of the examples, below::

    robot demo/sample_test_refactored.rst

    robot --variable SW1_HOST:localhost --variable SW1_PORT:61080 \
          --variable USERNAME:eapiuser --variable PASSWORD:icanttellyou \
          demo/sample_test_refactored.rst

    robot --variablefile demo/myvariables.py
          demo/sample_test_refactored.rst

Variable files
--------------

Variable files are just python modules with KEY = value pairs.

Example `myvariables.py`::

    """ My custom values for this test suite
    """

    SW1_HOST = 'localhost'
    SW1_PORT = 61080
    USERNAME = 'eapiuser'
    PASSWORD = 'icanttellyou'
    MLAG_DOMAIN = 'my_lag_domain'

Suite Setup
===========

.. code:: robotframework
   :class: hidden

    *** Settings ***
    Documentation    This is a sample Robot Framework suite which takes advantage of
    ...    the AristaLibrary for communicating with and controlling Arista switches.
    ...    Run with:
    ...    pybot --pythonpath=AristaLibrary --noncritical new demo/sample-test-refactored.txt

    Library    AristaLibrary
    Library    Collections
    Suite Setup    Connect To Switches
    Suite Teardown    Clear All Connections
    Force Tags    MLAG

    *** Variables ***
    ${TRANSPORT}    http
    ${SW1_HOST}    localhost
    ${SW1_PORT}    2080
    ${USERNAME}    vagrant
    ${PASSWORD}    vagrant

    *** Keywords ***
    Connect To Switches
        [Documentation]    Establish connection to a switch which gets used by test cases.
        ...                Gathers MLAG status. If MLAG not enabled, adds tag 'not_enabled' and passes.
        Connect To    host=${SW1_HOST}    transport=${TRANSPORT}    username=${USERNAME}    password=${PASSWORD}    port=${SW1_PORT}
        ${output}=    Enable    show mlag   json
        ${result}=    Get From Dictionary    ${output[0]}    result
        # Skip this suite if mlag is disabled
        Run Keyword If   "${result['state']}" == 'disabled'  Fail   MLAG not enabled on this device  not_enabled
        Set Suite Variable  ${MLAG}  ${result}
        Log    ${result}

    Domain should be ${expected}
        ${mlag}=    Mlag Domain
        Should Be Equal  ${mlag}  ${expected}

Test Cases
===============

.. code:: robotframework

    *** Test Cases ***
    State via manual check
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['state']}  active
        Should Be Equal     ${result['negStatus']}  connected

    Peer-link Is Up
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['peerLinkStatus']}  up  Peer-link ${result['peerLink']} is not up

    Local Interface Is Up
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['localIntfStatus']}  up    Local interface ${result['localInterface']} is not up

    Ports Are Not Error-disabled
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['portsErrdisabled']}  ${FALSE}  One or more ports are Errdisabled

    Ports are not disabled
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['mlagPorts']['Disabled']}  0   One or more ports are disabled

    All configured ports are active
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        Should Be Equal     ${result['mlagPorts']['Configured']}  ${result['mlagPorts']['Active-full']}

    Peer address is reachable
        [TAGS]  production
        ${result} =    Get Variable Value   ${MLAG}    "No_data"
        # Ping the peer address
        ${output}=    Enable    ping ${result['peerAddress']}    text
        ${result}=    Get From Dictionary    ${output[0]}    result
        Log    ${result}
        ${match}    ${group1}=    Should Match Regexp    ${result['output']}    (\\d+)% packet loss
        Should Be Equal As Integers    ${group1}    0    msg="Packets lost percent not zero!!!"

    Member ports are active
        [TAGS]  production
        ${output}=    Enable    show mlag interfaces members   json
        ${result}=    Get From Dictionary    ${output[0]}    result
        ${lags}=    Get Dictionary Keys     ${result['interfaces']}
        :FOR    ${mlag}  IN     @{lags}
        \       Log    ${mlag}
        \       Should Not Be Empty     ${result['interfaces']['${mlag}']['members']}
    #   #\       Check Mlag Member   ${mlag}

    State via method
        [TAGS]  production
        Verify Mlag State

    Verify domain setting
        [TAGS]  production
        Domain should be ${MLAG_DOMAIN}

End of testplan.
