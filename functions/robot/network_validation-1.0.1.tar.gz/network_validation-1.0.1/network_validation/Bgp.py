# Copyright (c) 2017, Arista Networks, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#   Redistributions of source code must retain the above copyright notice,
#   this list of conditions and the following disclaimer.
#
#   Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in the
#   documentation and/or other materials provided with the distribution.
#
#   Neither the name of Arista Networks nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ARISTA NETWORKS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
# BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
# IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

import re
import logging
from robot.libraries.BuiltIn import BuiltIn
from AristaLibrary import Expect

AE_ERR = 'AristaLibrary.Bgp: '       # Arista Bgp Error prefix


class Bgp(object):
    """Bgp - A Robot Framework library for analyzing Arista EOS
    BGP state.

    Keywords may be implemented here when Python provides a better solution than the Robot Framework language.

    The AristaLibrary Expect library is required for these keywords.

    nce a 'Get Command Output' keyword has been used for a given device
    the keywords herein may then be invoked to validate the content of
    the returned output. See the keyword documentation for specific details.

    Examples:

        Import the Arista Expect library:

            # Import the Arista Expect library, initializing the library
            # with the command 'show interfaces ethernet 1':
            *** Settings ***
            | Library | AristaLibrary |
            | Library | AristaLibrary.Expect | show interfaces ethernet 1 |
            | Library | network_validation.Bgp |

            # Import the Arista Expect library without initialization
            *** Settings ***
            | Library | AristaLibrary |
            | Library | AristaLibrary.Expect |
            | Library | network_validation.Bgp |

        Instruct the library to execute commands on devices and store
        the output of those commands:

            *** Test Cases ***

            # Get command output when a command has already been issued
            # or was initialized in the library import statement

            Get results for new command on switch 3 only
                | Get Command Output | switch_id=3 | cmd=show hostname |

            Get results for new command on all switches
                | Get Command Output | cmd=show hostname |

        NOTE: The Arista Expect library relies on the AristaLibrary for
        connection management. The AristaLibrary *must* be imported before
        the Arista Expect library to ensure proper access to the connection
        management routines.
    """
    ROBOT_LIBRARY_SCOPE = 'TEST_SUITE'

    def __init__(self, cmd=None):
        # Store the command passed in when the library is imported
        self.import_cmd = cmd
        # Get the AristaLibrary instance in use so we can reference
        # the list of connections
        self.arista_lib = BuiltIn().get_library_instance('AristaLibrary')
        # Initialize the switch_cmd and result dictionaries as empty
        self.switch_cmd = {}
        # Get the current result-set in the AristaLibrary.Expect library
        self.expect = BuiltIn().get_library_instance('AristaLibrary.Expect')
        self.result = self.expect.result

    # ---------------- Start Core Keywords ---------------- #

    def bgp_neighbors_should_be_up(self):
        """Scan through all BGP neighbors and they are established (up)

        Examples:
            BGP neighbors Are Estabished
                | Get Command Output | cmd=show ip bgp neighbors |
                | Bgp Neighbors Should Be Up |

            BGP neighbors Are Estabished
                | ${data}= | Get Command Output | cmd=show ip bgp neighbors |
                | Log | ${data} |
                | Bgp Neighbors Should Be Up |

        """
        # Get the index of the currently active switch
        index = self.arista_lib.get_switch()['index']
        # Get the current output of the command executed on this switch
        returned = self.result[index][u'output']

        sections = returned.split("\n \n")
        for sect in sections:
            logging.info(sect)
            if 'BGP state is' not in sect:
                continue
            match = re.search('BGP neighbor is (.*),', sect)
            neighbor = match.group(1)
            if 'BGP state is Established' not in sect:
                raise RuntimeError(
                    '{}BGP neighbor: \'{}\' state is not established'
                    .format(AE_ERR, neighbor)
                )
            else:
                logging.info("{} looks good".format(neighbor))
