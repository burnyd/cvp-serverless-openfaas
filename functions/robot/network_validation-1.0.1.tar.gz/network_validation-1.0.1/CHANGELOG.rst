Release 1.0.0 GA
----------------

Enhancements
^^^^^^^^^^^^

* Generate clean initial config file for users (`18 <https://github.com/arista-eosplus/network_validation/pull/18>`_) [`jerearista <https://github.com/jerearista>`_]
    .. comment

Fixed
^^^^^

* Cleanup included test files (`21 <https://github.com/arista-eosplus/network_validation/pull/21>`_) [`jerearista <https://github.com/jerearista>`_]
    .. comment
* TSV files contain extra tabs (`19 <https://github.com/arista-eosplus/network_validation/issues/19>`_) [`networkop <https://github.com/networkop>`_]
    .. comment
