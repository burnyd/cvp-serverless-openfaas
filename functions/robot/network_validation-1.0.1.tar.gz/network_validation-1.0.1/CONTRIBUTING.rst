Contributing to Network Validation
==================================

Network Validation welcomes suggestions, comments, and contributions from anyone.
Please use GitHub Issues to file issues, whether bugs or requests for
enhancements.

Contributing tests
------------------

Download the source
-------------------

::

    git clone https://github.com/arista-eosplus/network_validation.git
    cd network_validation
    # optionally start a virtualenv
    virtualenv venv
    . venv/bin/activate
    # Install the package in develop mode - "Editable"
    python setup.py develop
    cp config/sample.yml network_validation.yml

Create a local directory for your tests and add that to the testfiles list in
the YAML configuration file.

Submitting new tests or changes to existing code
------------------------------------------------

There is a great `blog post
<https://www.gun.io/blog/how-to-github-fork-branch-and-pull-request>` on
forking a repository, then submitting a pull-request with your changes to the
original repository.  Be sure to work off of and submit pull request to the
``develop`` branch instead of ``master``.

* Ensure all tests pass when running against EOS (or vEOS).

  * If you have a vEOS vagrant box and VirtualBox, then run
    ``cd atest/; run_atests_veos.sh``.  This will spin up 2 vEOS nodes,
    interconnected on Et1, then execute the tests with pybot.
    See ``cd atest/; run_atests_veos.sh --help`` for options.

* Submit a Pull Reuest

Creating an installation package
--------------------------------

To create a release distribution package, ensure your working directory is
clean (``git status``), Update the version and create a tag if needed, then run
``python setup.py sdist``.  The tar.gz file will be in the ``dist/`` directory.

A user can install from that package using `pip`::

    pip install /<path to>/network_validation-0.1.tar.gz

Debugging inside Robot
----------------------

To enter the Python debugger within a Python keyword, see `Using the Python
debugger
<http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#using-the-python-debugger-pdb>`
and insert the following line::

    import sys, pdb; pdb.Pdb(stdout=sys.__stdout__).set_trace()

Contact
-------

Please contact eosplus-dev@arista.com with any questions or comments on this
library.
