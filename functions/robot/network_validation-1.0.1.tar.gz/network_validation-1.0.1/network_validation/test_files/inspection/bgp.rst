=========================
Verify basic BGP function
=========================

.. raw:: html

   <!-- This class allows us to hide the test setup part -->
   <style type="text/css">.hidden { display: none; }</style>

.. contents::
    :local:

This example demonstrates how RobotFramework tests can be embedded in
ReStructuredText documentation.  If you are converting an existing
tab-separated test suite, convert tabs to 4-spaces within the RST file.

The testcases should be in `code:: robotframework` blocks.

Installing RobotFramework
=========================

To execute this test, setup the following::

    pip install robotframework docutils Pygments
    git clone https://github.com/arista-eosplus/robotframework-aristalibrary.git
    cd robotframework-aristalibrary/
    python setup.py install


Executing tests
===============

Start tests using one of the examples, below::

    robot demo/sample_test_refactored.rst

    robot --variable SW1_HOST:localhost --variable SW1_PORT:61080 \
          --variable USERNAME:eapiuser --variable PASSWORD:icanttellyou \
          demo/sample_test_refactored.rst

    robot --variablefile demo/myvariables.py
          demo/sample_test_refactored.rst

Variable files
--------------

Variable files are just python modules with KEY = value pairs.

Example `myvariables.py`::

    """ My custom values for this test suite
    """

    SW1_HOST = 'localhost'
    SW1_PORT = 61080
    USERNAME = 'eapiuser'
    PASSWORD = 'icanttellyou'
    MLAG_DOMAIN = 'my_lag_domain'

Suite Setup
===========

.. code:: robotframework
   :class: hidden

    *** Settings ***
    Library    AristaLibrary
    Library    AristaLibrary.Expect
    Library    network_validation.Bgp
    Library    Collections
    Library    String
    Suite Setup    Connect To Switches
    Suite Teardown    Clear All Connections
    Force Tags    BGP

    *** Variables ***
    ${TRANSPORT}    http
    ${SW1_HOST}    localhost
    ${SW1_PORT}    2080
    ${USERNAME}    vagrant
    ${PASSWORD}    vagrant

    *** Keywords ***
    Connect To Switches
        [Documentation]    Establish connection to a switch which gets used by test cases.
        Connect To    host=${SW1_HOST}    transport=${TRANSPORT}    username=${USERNAME}    password=${PASSWORD}    port=${SW1_PORT}
        ${result}=  Get Command Output  cmd=show running-config section router bgp
        # Skip this suite if mlag is disabled
        Run Keyword If   'router bgp' not in "${result}"  Fail   BGP is not configured on this device  not_enabled
        #${output}=    Enable    show running-config section router bgp   text
        #${result}=    Get From Dictionary    ${output[0]}    result
        #${result}=    Get From Dictionary    ${result}    output
        ## Skip this suite if BGP is not configured
        ##Run Keyword If   "${result}" == ''  Fail   BGP not configured on this device  not_enabled
        Set Suite Variable  ${BGP_CONFIG}  ${result}

Test Cases
===============

.. code:: robotframework

    *** Test Cases ***
    BGP neighbors Are Estabished
        [TAGS]  production
        ${data}=  Get Command Output	cmd=show ip bgp neighbors
        Log  ${data}
        Bgp Neighbors Should Be Up

End of testplan.
